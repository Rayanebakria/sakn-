// AI Decision Making System for Housing Applications

class HousingAI {
    constructor() {
        this.weights = {
            maritalStatus: {
                'أعزب': 10,
                'متزوج': 20,
                'مطلق': 15,
                'أرمل': 18
            },
            housingType: {
                'مع العائلة': 10,
                'مستأجر': 20,
                'سكن هش': 30,
                'بدون سكن': 40
            },
            jobStatus: {
                'بطال': 25,
                'عامل يومي': 20,
                'متقاعد': 15,
                'حرفي': 12,
                'موظف': 8
            },
            incomeThresholds: {
                veryLow: { max: 20000, points: 30 },
                low: { max: 40000, points: 15 },
                medium: { max: 60000, points: 5 },
                high: { max: Infinity, points: 0 }
            }
        };
        
        this.decisionThresholds = {
            accepted: 90,
            underReview: 60,
            rejected: 0
        };
    }

    // Calculate priority score based on application data
    calculatePriority(applicationData) {
        let score = 0;
        const details = [];

        // 1. Marital Status Points
        const maritalPoints = this.weights.maritalStatus[applicationData.status] || 0;
        score += maritalPoints;
        details.push(`الحالة المدنية (${applicationData.status}): ${maritalPoints} نقطة`);

        // 2. Children Count Points (5 points per child, max 25)
        const childrenCount = parseInt(applicationData.children_count) || 0;
        const childrenPoints = Math.min(childrenCount * 5, 25);
        score += childrenPoints;
        details.push(`عدد الأطفال (${childrenCount}): ${childrenPoints} نقطة`);

        // 3. Housing Type Points
        const housingPoints = this.weights.housingType[applicationData.housing_type] || 0;
        score += housingPoints;
        details.push(`نوع السكن (${applicationData.housing_type}): ${housingPoints} نقطة`);

        // 4. Income Points
        const salary = parseInt(applicationData.salary) || 0;
        const incomePoints = this.calculateIncomePoints(salary);
        score += incomePoints;
        details.push(`الدخل الشهري (${salary} دج): ${incomePoints} نقطة`);

        // 5. Job Status Points
        const jobPoints = this.weights.jobStatus[applicationData.job_status] || 0;
        score += jobPoints;
        details.push(`الوضعية المهنية (${applicationData.job_status}): ${jobPoints} نقطة`);

        // 6. Residency Years Points (1 point per year, max 20)
        const residencyYears = parseInt(applicationData.residency_years) || 0;
        const residencyPoints = Math.min(residencyYears, 20);
        score += residencyPoints;
        details.push(`سنوات الإقامة (${residencyYears}): ${residencyPoints} نقطة`);

        return {
            score,
            details,
            maxPossible: 120
        };
    }

    // Calculate income-based points
    calculateIncomePoints(salary) {
        for (const [level, threshold] of Object.entries(this.weights.incomeThresholds)) {
            if (salary <= threshold.max) {
                return threshold.points;
            }
        }
        return 0;
    }

    // Make final decision based on score
    makeDecision(score) {
        if (score >= this.decisionThresholds.accepted) {
            return {
                status: 'مقبول',
                reason: 'تستوفي جميع الشروط المطلوبة',
                color: 'success',
                icon: '✅'
            };
        } else if (score >= this.decisionThresholds.underReview) {
            return {
                status: 'قيد الدراسة',
                reason: 'طلبك قيد المراجعة من قبل اللجنة المختصة',
                color: 'warning',
                icon: '⏳'
            };
        } else {
            return {
                status: 'مرفوض',
                reason: 'لا تستوفي الحد الأدنى من الشروط المطلوبة',
                color: 'danger',
                icon: '❌'
            };
        }
    }

    // Generate detailed assessment report
    generateAssessmentReport(applicationData) {
        const priorityResult = this.calculatePriority(applicationData);
        const decision = this.makeDecision(priorityResult.score);
        
        return {
            applicantName: `${applicationData.first_ar} ${applicationData.last_ar}`,
            nationalId: applicationData.national_id,
            priorityScore: priorityResult.score,
            maxScore: priorityResult.maxPossible,
            percentage: Math.round((priorityResult.score / priorityResult.maxPossible) * 100),
            decision: decision,
            scoreDetails: priorityResult.details,
            assessmentDate: new Date().toLocaleDateString('ar-SA'),
            recommendations: this.generateRecommendations(applicationData, priorityResult.score)
        };
    }

    // Generate recommendations based on application
    generateRecommendations(applicationData, score) {
        const recommendations = [];
        
        if (score < this.decisionThresholds.accepted) {
            if (applicationData.housing_type === 'مع العائلة') {
                recommendations.push('قم بتوثيق وضعيتك السكنية الحالية بشكل أفضل');
            }
            
            if (parseInt(applicationData.salary) > 40000) {
                recommendations.push('راجع إمكانية الحصول على سكن بنظام البيع بالتقسيط');
            }
            
            if (parseInt(applicationData.residency_years) < 5) {
                recommendations.push('انتظر حتى تكمل فترة إقامة أطول في البلدية');
            }
        }
        
        if (applicationData.job_status === 'بطال') {
            recommendations.push('احرص على تحديث وضعيتك المهنية عند حدوث تغيير');
        }
        
        return recommendations;
    }

    // Validate application data before processing
    validateApplicationData(data) {
        const required = [
            'status', 'housing_type', 'job_status',
            'first_ar', 'last_ar', 'national_id'
        ];
        
        const errors = [];
        
        required.forEach(field => {
            if (!data[field]) {
                errors.push(`حقل ${field} مطلوب`);
            }
        });
        
        if (data.national_id && data.national_id.length < 8) {
            errors.push('رقم التعريف الوطني غير صحيح');
        }
        
        if (data.children_count && (parseInt(data.children_count) < 0 || parseInt(data.children_count) > 20)) {
            errors.push('عدد الأطفال غير صحيح');
        }
        
        if (data.salary && parseInt(data.salary) < 0) {
            errors.push('الراتب يجب أن يكون رقماً موجباً');
        }
        
        return {
            isValid: errors.length === 0,
            errors
        };
    }

    // Get statistics for admin dashboard
    getApplicationStatistics(applications) {
        const stats = {
            total: applications.length,
            accepted: 0,
            rejected: 0,
            underReview: 0,
            averageScore: 0,
            scoreDistribution: {
                high: 0,    // 90-100
                medium: 0,  // 60-89
                low: 0      // 0-59
            }
        };
        
        let totalScore = 0;
        
        applications.forEach(app => {
            const score = app.priority_score || 0;
            totalScore += score;
            
            // Count by status
            switch(app.status) {
                case 'مقبول': stats.accepted++; break;
                case 'مرفوض': stats.rejected++; break;
                case 'قيد الدراسة': stats.underReview++; break;
            }
            
            // Score distribution
            if (score >= 90) {
                stats.scoreDistribution.high++;
            } else if (score >= 60) {
                stats.scoreDistribution.medium++;
            } else {
                stats.scoreDistribution.low++;
            }
        });
        
        stats.averageScore = applications.length > 0 ? 
            Math.round(totalScore / applications.length) : 0;
        
        return stats;
    }
}

// Create global instance
const housingAI = new HousingAI();

// Export functions for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        HousingAI,
        housingAI
    };
}

// Helper function for server-side use
function calculateApplicationPriority(applicationData) {
    const validation = housingAI.validateApplicationData(applicationData);
    if (!validation.isValid) {
        throw new Error(`Invalid application data: ${validation.errors.join(', ')}`);
    }
    
    const assessment = housingAI.generateAssessmentReport(applicationData);
    return {
        decision: assessment.decision.status,
        priority: assessment.priorityScore,
        percentage: assessment.percentage,
        details: assessment
    };
}

// Make available globally
if (typeof window !== 'undefined') {
    window.housingAI = housingAI;
    window.calculateApplicationPriority = calculateApplicationPriority;
}
