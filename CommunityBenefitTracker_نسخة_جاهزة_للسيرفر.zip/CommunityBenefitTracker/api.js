// API utility functions for the housing management system

class HousingAPI {
    constructor() {
        this.baseURL = '';
    }

    // Generic API request method
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || `HTTP Error: ${response.status}`);
            }
            
            return data;
        } catch (error) {
            console.error('API Request Error:', error);
            throw error;
        }
    }

    // Authentication APIs
    async login(email, password) {
        return this.request('/api/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
    }

    async logout() {
        return this.request('/api/logout', {
            method: 'POST'
        });
    }

    // Application APIs
    async submitApplication(formData) {
        return fetch('/api/submit-application', {
            method: 'POST',
            body: formData // FormData object for file uploads
        }).then(response => response.json());
    }

    // Beneficiaries APIs
    async getBeneficiaries(filters = {}) {
        const params = new URLSearchParams(filters);
        return this.request(`/api/beneficiaries?${params}`);
    }

    async addBeneficiary(beneficiaryData) {
        return this.request('/api/beneficiaries', {
            method: 'POST',
            body: JSON.stringify(beneficiaryData)
        });
    }

    async updateBeneficiary(id, beneficiaryData) {
        return this.request(`/api/beneficiaries/${id}`, {
            method: 'PUT',
            body: JSON.stringify(beneficiaryData)
        });
    }

    async deleteBeneficiary(id) {
        return this.request(`/api/beneficiaries/${id}`, {
            method: 'DELETE'
        });
    }

    // Chat API
    async sendChatMessage(message) {
        return this.request('/api/chat', {
            method: 'POST',
            body: JSON.stringify({ message })
        });
    }
}

// Create global API instance
const housingAPI = new HousingAPI();

// Helper functions for common operations
async function authenticateUser(email, password) {
    try {
        const result = await housingAPI.login(email, password);
        if (result.success) {
            return { success: true, message: result.message };
        } else {
            return { success: false, error: result.error };
        }
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function logoutUser() {
    try {
        await housingAPI.logout();
        return true;
    } catch (error) {
        console.error('Logout error:', error);
        return false;
    }
}

async function loadBeneficiariesData(filters = {}) {
    try {
        const data = await housingAPI.getBeneficiaries(filters);
        return {
            success: true,
            beneficiaries: data.beneficiaries || [],
            stats: data.stats || {}
        };
    } catch (error) {
        console.error('Error loading beneficiaries:', error);
        return {
            success: false,
            error: error.message,
            beneficiaries: [],
            stats: {}
        };
    }
}

async function saveBeneficiary(beneficiaryData) {
    try {
        const result = await housingAPI.addBeneficiary(beneficiaryData);
        return { success: true, message: result.message };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function updateBeneficiaryData(id, beneficiaryData) {
    try {
        const result = await housingAPI.updateBeneficiary(id, beneficiaryData);
        return { success: true, message: result.message };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function removeBeneficiary(id) {
    try {
        const result = await housingAPI.deleteBeneficiary(id);
        return { success: true, message: result.message };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

async function submitHousingApplication(formData) {
    try {
        const result = await housingAPI.submitApplication(formData);
        return {
            success: result.success,
            decision: result.decision,
            priority: result.priority,
            message: result.message,
            error: result.error
        };
    } catch (error) {
        return {
            success: false,
            error: error.message
        };
    }
}

// Form validation helpers
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validateNationalId(nationalId) {
    // Algerian national ID validation (basic check)
    return nationalId && nationalId.length >= 8;
}

function validatePhone(phone) {
    // Algerian phone number validation (basic check)
    const re = /^[0-9+\-\s()]+$/;
    return re.test(phone) && phone.length >= 8;
}

// Form processing helpers
function extractFormData(form) {
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    return data;
}

function displayMessage(elementId, type, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.className = `alert alert-${type}`;
        element.textContent = message;
        element.classList.remove('d-none');
        
        // Auto-hide success messages after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                element.classList.add('d-none');
            }, 5000);
        }
    }
}

function clearMessage(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.add('d-none');
    }
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        HousingAPI,
        housingAPI,
        authenticateUser,
        logoutUser,
        loadBeneficiariesData,
        saveBeneficiary,
        updateBeneficiaryData,
        removeBeneficiary,
        submitHousingApplication,
        validateEmail,
        validateNationalId,
        validatePhone,
        extractFormData,
        displayMessage,
        clearMessage
    };
}
