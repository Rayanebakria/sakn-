// Global chat functionality
let chatbotVisible = false;

function openChatbot() {
    document.getElementById('chatbot').style.display = 'block';
    chatbotVisible = true;
}

function closeChatbot() {
    document.getElementById('chatbot').style.display = 'none';
    chatbotVisible = false;
}

async function sendMessage() {
    const inputBox = document.getElementById("userInput");
    const input = inputBox.value.trim();
    if (!input) return;

    const chatbox = document.getElementById("chatbox");
    
    // Add user message
    const userMessage = document.createElement('div');
    userMessage.className = 'user-message';
    userMessage.innerHTML = `<b>أنت:</b> ${input}`;
    chatbox.appendChild(userMessage);

    // Clear input
    inputBox.value = "";
    
    // Show loading with typing animation
    const loadingMessage = document.createElement('div');
    loadingMessage.className = 'bot-message loading-message';
    loadingMessage.innerHTML = `
        <b>🤖 المساعد الذكي (ChatGPT):</b> 
        <span class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
        </span>
        جاري كتابة الرد...
    `;
    chatbox.appendChild(loadingMessage);
    chatbox.scrollTop = chatbox.scrollHeight;

    try {
        const response = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: input })
        });

        const data = await response.json();
        
        // Remove loading message
        chatbox.removeChild(loadingMessage);
        
        // Add bot response with AI indicator
        const botMessage = document.createElement('div');
        botMessage.className = 'bot-message ai-response';
        botMessage.innerHTML = `
            <div class="message-header">
                <b>🤖 المساعد الذكي (ChatGPT)</b>
                <span class="ai-badge">AI</span>
            </div>
            <div class="message-content">${data.response}</div>
        `;
        chatbox.appendChild(botMessage);
        
    } catch (error) {
        console.error('Chat error:', error);
        
        // Remove loading message
        chatbox.removeChild(loadingMessage);
        
        // Add error message
        const errorMessage = document.createElement('div');
        errorMessage.className = 'bot-message error-message';
        errorMessage.innerHTML = `
            <b>⚠️ خطأ في الاتصال:</b> 
            عذراً، لا يمكن الوصول للمساعد الذكي حالياً. يرجى المحاولة مرة أخرى.
        `;
        chatbox.appendChild(errorMessage);
    }

    chatbox.scrollTop = chatbox.scrollHeight;
}

// Utility functions
function showLoading(element) {
    if (element) {
        element.innerHTML = '<span class="loading"></span>';
    }
}

function hideLoading(element, originalContent) {
    if (element) {
        element.innerHTML = originalContent;
    }
}

// Form validation utilities
function validateForm(formElement) {
    const requiredFields = formElement.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
        }
    });
    
    return isValid;
}

// Format utilities
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA');
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-DZ', {
        style: 'currency',
        currency: 'DZD'
    }).format(amount);
}

// Error handling
function handleApiError(error, defaultMessage = 'حدث خطأ غير متوقع') {
    console.error('API Error:', error);
    return error.message || defaultMessage;
}

// Storage utilities
function saveToLocalStorage(key, data) {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error('Error saving to localStorage:', error);
    }
}

function getFromLocalStorage(key) {
    try {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    } catch (error) {
        console.error('Error reading from localStorage:', error);
        return null;
    }
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    // Initialize any global functionality
    console.log('Housing Management System initialized');
    
    // Add global event listeners
    document.addEventListener('keydown', function(e) {
        // Close chatbot with Escape key
        if (e.key === 'Escape' && chatbotVisible) {
            closeChatbot();
        }
    });
});
