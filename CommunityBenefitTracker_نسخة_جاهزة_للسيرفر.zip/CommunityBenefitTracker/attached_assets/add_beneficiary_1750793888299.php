<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "housing_db");
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $national_id = $_POST['national_id'];
    $commune = $_POST['commune'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO beneficiaries (full_name, national_id, commune, status) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $full_name, $national_id, $commune, $status);

    if ($stmt->execute()) {
        header("Location: beneficiaries_list.php");
        exit();
    } else {
        $error = "فشل في إضافة المستفيد.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>إضافة مستفيد جديد</title>
    <style>
        body {
            font-family: Arial;
            direction: rtl;
            background-color: #f9f9f9;
            padding: 20px;
        }
        form {
            max-width: 500px;
            background-color: #fff;
            margin: auto;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label, input, select {
            display: block;
            width: 100%;
            margin-bottom: 15px;
            font-size: 16px;
        }
        input, select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>

<h2 style="text-align:center;">➕ إضافة مستفيد جديد</h2>

<?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

<form method="POST" action="">
    <label>الاسم الكامل</label>
    <input type="text" name="full_name" required>

    <label>رقم التعريف الوطني</label>
    <input type="text" name="national_id" required>

    <label>البلدية</label>
    <input type="text" name="commune" required>

    <label>الحالة</label>
    <select name="status" required>
        <option value="قيد الدراسة">قيد الدراسة</option>
        <option value="مقبول">مقبول</option>
        <option value="مرفوض">مرفوض</option>
    </select>

    <button type="submit">✔️ حفظ</button>
</form>

</body>
</html>
