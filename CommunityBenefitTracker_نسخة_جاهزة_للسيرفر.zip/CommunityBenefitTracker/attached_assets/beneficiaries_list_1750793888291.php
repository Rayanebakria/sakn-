<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "housing_db");
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

$search = isset($_GET['search']) ? $_GET['search'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$commune_filter = isset($_GET['commune']) ? $_GET['commune'] : '';

$query = "SELECT * FROM beneficiaries WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND full_name LIKE ?";
    $params[] = "%$search%";
}

if (!empty($status_filter)) {
    $query .= " AND status = ?";
    $params[] = $status_filter;
}

if (!empty($commune_filter)) {
    $query .= " AND commune = ?";
    $params[] = $commune_filter;
}

$query .= " ORDER BY id ASC";
$stmt = $conn->prepare($query);

if ($params) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$total = $conn->query("SELECT COUNT(*) as c FROM beneficiaries")->fetch_assoc()['c'];
$accepted = $conn->query("SELECT COUNT(*) as c FROM beneficiaries WHERE status = 'مقبول'")->fetch_assoc()['c'];
$rejected = $conn->query("SELECT COUNT(*) as c FROM beneficiaries WHERE status = 'مرفوض'")->fetch_assoc()['c'];
$pending = $conn->query("SELECT COUNT(*) as c FROM beneficiaries WHERE status = 'قيد الدراسة'")->fetch_assoc()['c'];

$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>سكنات اجتماعية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
    }
    body {
      background: linear-gradient(to bottom right, #0d1b2a, #1b263b);
      font-family: 'Cairo', sans-serif;
      color: #f0f0f0;
      background-image: url('https://chatgpt.com/s/m_6851cdd3f79c8191a711a31b9ba500c9');
      background-repeat: no-repeat;
      background-position: center;
      background-size: 70%;
      background-attachment: fixed;
    }
    .overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(13, 27, 42, 0.95);
      z-index: -1;
    }
    .card {
      border-radius: 20px;
      background-color: #1c2541;
      color: white;
      box-shadow: 0 5px 25px rgba(0,0,0,0.6);
    }
    .table {
      background-color: #1b263b;
      color: white;
      border-radius: 10px;
      border-collapse: separate;
      border-spacing: 0 0.4rem;
      box-shadow: 0 0 12px rgba(0, 0, 0, 0.5);
    }
    .table thead {
      background-color: #415a77;
    }
    .table-striped tbody tr:nth-of-type(odd) {
      background-color: #2c3e50;
    }
    .btn-add {
      background-color: #00ffaa;
      color: black;
      border-radius: 20px;
      font-weight: bold;
    }
    .btn-edit {
      background-color: #ffaa00;
      color: black;
      border-radius: 10px;
      font-weight: bold;
    }
    .btn-delete {
      background-color: #ff4444;
      color: white;
      border-radius: 10px;
      font-weight: bold;
    }
    .form-control, .form-select {
      background-color: #e0e0e0;
      border-radius: 10px;
    }
  </style>
</head>
<body class="container-fluid py-4 position-relative">
  <div class="overlay"></div>

  <h2 class="text-center mb-4" style="font-size: 2.2rem; font-weight: bold;">
    سكنات اجتماعية
  </h2>

  <div class="row mb-3">
    <div class="col-md-3">
      <div class="card p-3 text-center">
        <h5>📊 مجموع الطلبات</h5>
        <h3><?= $total ?></h3>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-3 text-center">
        <h5>✅ المقبولة</h5>
        <h3><?= $accepted ?></h3>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-3 text-center">
        <h5>❌ المرفوضة</h5>
        <h3><?= $rejected ?></h3>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card p-3 text-center">
        <h5>⏳ قيد الدراسة</h5>
        <h3><?= $pending ?></h3>
      </div>
    </div>
  </div>

  <form class="row g-2 mb-3" method="GET">
    <div class="col-md-4">
      <input type="text" class="form-control" name="search" placeholder="🔍 ابحث بالاسم" value="<?= htmlspecialchars($search) ?>">
    </div>
    <div class="col-md-3">
      <select name="status" class="form-select">
        <option value="">🧾 الحالة</option>
        <option value="مقبول" <?= $status_filter == 'مقبول' ? 'selected' : '' ?>>✅ مقبول</option>
        <option value="مرفوض" <?= $status_filter == 'مرفوض' ? 'selected' : '' ?>>❌ مرفوض</option>
        <option value="قيد الدراسة" <?= $status_filter == 'قيد الدراسة' ? 'selected' : '' ?>>⏳ قيد الدراسة</option>
      </select>
    </div>
    <div class="col-md-3">
      <input type="text" class="form-control" name="commune" placeholder="🏘️ البلدية" value="<?= htmlspecialchars($commune_filter) ?>">
    </div>
    <div class="col-md-2">
      <button class="btn btn-primary w-100">🔎 تصفية</button>
    </div>
  </form>

  <div class="mb-3 text-end">
    <a href="add_beneficiary.php" class="btn btn-add">➕ إضافة مستفيد جديد</a>
  </div>

  <table class="table table-bordered table-striped shadow">
    <thead>
      <tr>
        <th>الترتيب</th>
        <th>الاسم الكامل</th>
        <th>رقم التعريف الوطني</th>
        <th>البلدية</th>
        <th>الحالة</th>
        <th>الخيارات</th>
      </tr>
    </thead>
    <tbody>
      <?php $counter = 1; foreach ($rows as $row): ?>
        <tr>
          <td><?= $counter++ ?></td>
          <td><?= htmlspecialchars($row['full_name']) ?></td>
          <td><?= htmlspecialchars($row['national_id']) ?></td>
          <td><?= htmlspecialchars($row['commune']) ?></td>
          <td><?= htmlspecialchars($row['status']) ?></td>
          <td>
            <a href="edit_beneficiary.php?id=<?= $row['id'] ?>" class="btn btn-edit btn-sm">✏️ تعديل</a>
            <a href="delete_beneficiary.php?id=<?= $row['id'] ?>" class="btn btn-delete btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')">🗑️ حذف</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</body>
</html>
