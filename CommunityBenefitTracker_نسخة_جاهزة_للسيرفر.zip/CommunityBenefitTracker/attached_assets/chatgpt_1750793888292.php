<?php
header('Content-Type: application/json');

$apiKey = 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
$input = json_decode(file_get_contents("php://input"), true);
$userMessage = $input['message'];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.openai.com/v1/chat/completions");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);

$headers = [
    "Authorization: Bearer $apiKey",
    "Content-Type: application/json"
];

$postData = [
    "model" => "gpt-3.5-turbo",
    "messages" => [
        ["role" => "system", "content" => "أنت مساعد ذكي للمنصة الرقمية للسكنات الاجتماعية في الجزائر، تجيب باللغة العربية."],
        ["role" => "user", "content" => $userMessage]
    ]
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
$reply = $data['choices'][0]['message']['content'] ?? "❓ حدث خطأ في الاتصال بـ ChatGPT.";

echo json_encode(["reply" => $reply]);
