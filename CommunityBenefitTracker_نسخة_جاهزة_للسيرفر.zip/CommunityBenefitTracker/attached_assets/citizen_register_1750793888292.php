<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>المنصة الرقمية للسكنات الاجتماعية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Cairo', sans-serif;
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      color: white;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      position: relative;
    }

    .navbar {
      background-color: rgba(0,0,0,0.4);
      padding: 15px;
      text-align: center;
      position: relative;
    }

    .navbar a {
      color: white;
      margin: 0 15px;
      text-decoration: none;
      font-weight: bold;
    }

    .lang-switch {
      position: absolute;
      right: 20px;
      top: 65px;
      color: white;
      font-weight: bold;
      cursor: pointer;
      z-index: 1000;
    }

    .header {
      text-align: center;
      margin-top: 20px;
    }

    .header h1,
    .header h2,
    .header h3 {
      font-size: 1rem;
      font-weight: bold;
      margin: 10px 0;
    }

    .main-content {
      margin-top: 50px;
      text-align: center;
    }

    .btn-container {
      display: flex;
      flex-direction: column;
      gap: 20px;
      align-items: center;
      margin-top: 40px;
    }

    .btn-custom {
      width: 320px;
      padding: 25px;
      font-size: 1.6rem;
      border: none;
      border-radius: 10px;
      transition: 0.3s;
      font-weight: bold;
    }

    .btn-login {
      background-color: #007bff;
      color: white;
    }

    .btn-login:hover {
      background-color: #0056b3;
    }

    .btn-signup {
      background-color: #28a745;
      color: white;
    }

    .btn-signup:hover {
      background-color: #1e7e34;
    }

    .info-box {
      max-width: 800px;
      margin: 50px auto;
      text-align: right;
      background: rgba(255, 255, 255, 0.1);
      padding: 30px;
      border-radius: 15px;
    }
  </style>
  <script>
    function toggleLanguage() {
      const currentLang = document.documentElement.lang;
      if (currentLang === 'ar') {
        document.documentElement.lang = 'fr';
        document.documentElement.dir = 'ltr';
        document.querySelector('.header h1').innerText = "République Algérienne Démocratique et Populaire";
        document.querySelector('.header h2').innerText = "Ministère de l'Habitat et de l'Urbanisme";
        document.querySelector('.header h3').innerText = "Plateforme Numérique du Logement Social";
        document.querySelector('.btn-login').innerText = "🔐 Se connecter";
        document.querySelector('.btn-signup').innerText = "📝 Créer un compte";
        document.querySelectorAll('.navbar a')[0].innerText = "Accueil";
        document.querySelectorAll('.navbar a')[1].innerText = "FAQ";
        document.querySelectorAll('.navbar a')[2].innerText = "Conditions";
        document.querySelectorAll('.navbar a')[3].innerText = "Support";
        document.querySelectorAll('.navbar a')[4].innerText = "À propos";
        document.querySelectorAll('.navbar a')[5].innerText = "Contact";
        document.querySelector('.info-box h4:nth-of-type(1)').innerText = "📋 Étapes d'inscription:";
        document.querySelector('.info-box ul:nth-of-type(1)').innerHTML = "<li>Créer un compte</li><li>Remplir le formulaire</li><li>Télécharger les documents</li><li>Confirmer l'inscription</li><li>Suivre la demande</li>";
        document.querySelector('.info-box h4:nth-of-type(2)').innerText = "📄 Documents requis:";
        document.querySelector('.info-box ul:nth-of-type(2)').innerHTML = "<li>Copie de la carte d'identité</li><li>Certificat de résidence</li><li>Attestation de non-propriété</li><li>Bulletin de salaire ou revenu</li><li>Livret de famille</li>";
      } else {
        location.reload();
      }
    }
  </script>
</head>
<body>
  <div class="navbar">
    <a href="#">الرئيسية</a>
    <a href="#">الأسئلة الشائعة</a>
    <a href="#">الشروط والأحكام</a>
    <a href="#">الدعم والمساعدة</a>
    <a href="#">من نحن</a>
    <a href="#">اتصل بنا</a>
  </div>

  <div class="lang-switch" onclick="toggleLanguage()">
    🇩🇿 AR / FR 🇫🇷
  </div>

  <div class="header">
    <h1>الجمهورية الجزائرية الديمقراطية الشعبية</h1>
    <h2>وزارة السكن و العمران</h2>
    <h3>المنصة الرقمية للسكنات الاجتماعية</h3>
  </div>

  <div class="btn-container">
    <a href="login.php" class="btn btn-custom btn-login">🔐 تسجيل الدخول</a>
    <a href="signup.php" class="btn btn-custom btn-signup">📝 إنشاء حساب</a>
  </div>

  <div class="main-content">
    <div class="info-box">
      <h4>📋 خطوات التسجيل:</h4>
      <ul>
        <li>إنشاء حساب</li>
        <li>تعبئة الاستمارة</li>
        <li>رفع الوثائق</li>
        <li>تأكيد التسجيل</li>
        <li>متابعة الطلب</li>
      </ul>

      <h4>📄 الوثائق المطلوبة:</h4>
      <ul>
        <li>نسخة من بطاقة الهوية</li>
        <li>شهادة الإقامة</li>
        <li>شهادة عدم الملكية</li>
        <li>كشف الراتب أو الدخل</li>
        <li>شهادة عائلية</li>
      </ul>
    </div>
  </div>

</body><!-- واجهة الشات -->
<div id="chatbot" style="position: fixed; bottom: 20px; left: 20px; background-color: white; color: black; border-radius: 10px; width: 300px; box-shadow: 0 0 10px rgba(0,0,0,0.5); display: none; z-index: 9999;">
  <div style="background-color: #2c5364; color: white; padding: 10px; border-top-left-radius: 10px; border-top-right-radius: 10px;">
    مساعد السكنات الاجتماعية
    <span style="float: left; cursor: pointer;" onclick="document.getElementById('chatbot').style.display='none'">✖</span>
  </div>
  <div id="chatbox" style="height: 200px; overflow-y: auto; padding: 10px;"></div>
  <input type="text" id="userInput" placeholder="اكتب سؤالك..." style="width: 100%; border: none; border-top: 1px solid #ccc; padding: 10px;" onkeydown="if(event.key==='Enter') sendMessage()">
</div>

<!-- زر إظهار الشات -->
<button onclick="document.getElementById('chatbot').style.display='block'" style="position: fixed; bottom: 20px; left: 20px; background-color: #28a745; color: white; border: none; border-radius: 50%; width: 50px; height: 50px; font-size: 24px; cursor: pointer; z-index: 9999;">💬</button>

<!-- جافاسكريبت لربط الشات بـ chatgpt.php -->
<script>
async function sendMessage() {
  const inputBox = document.getElementById("userInput");
  const input = inputBox.value.trim();
  if (!input) return;

  const chatbox = document.getElementById("chatbox");
  chatbox.innerHTML += `<div><b>أنت:</b> ${input}</div>`;

  const response = await fetch("chatgpt.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: input })
  });

  const data = await response.json();
  chatbox.innerHTML += `<div><b>المساعد:</b> ${data.reply}</div>`;

  inputBox.value = "";
  chatbox.scrollTop = chatbox.scrollHeight;
}
</script>

</html>

