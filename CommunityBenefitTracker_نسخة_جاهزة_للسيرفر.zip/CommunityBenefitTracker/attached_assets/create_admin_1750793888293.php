<?php
include 'db.php'; // تأكد أن db.php في نفس المجلد

$email = 'rayanebakria13@gmail.com';
$password = 'bakria1999';

// تشفير كلمة المرور
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// تحضير الاستعلام
$stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $hashed_password);

// تنفيذ الإضافة
if ($stmt->execute()) {
    echo "✅ تم إنشاء المستخدم المدير بنجاح. يمكنك الآن <a href='login.php'>تسجيل الدخول</a>";
} else {
    echo "❌ فشل في إنشاء المستخدم: " . $stmt->error;
}

// إغلاق الاتصال
$stmt->close();
$conn->close();
?>
