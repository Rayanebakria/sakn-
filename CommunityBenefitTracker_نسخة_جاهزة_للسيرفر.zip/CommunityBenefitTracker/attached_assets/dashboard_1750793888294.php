<?php
session_start();

// إذا لم يتم تسجيل الدخول، نعيد المستخدم إلى صفحة تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>لوحة التحكم</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            direction: rtl;
            text-align: center;
            background-color: #f0f2f5;
        }
        h1 {
            color: #333;
        }
        .container {
            margin-top: 50px;
        }
        a.button {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }
        a.button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>👋 مرحبًا بك في لوحة تحكم المدير</h1>
        <p>يمكنك الآن إدارة النظام.</p>
        
        <a class="button" href="logout.php">🔓 تسجيل الخروج</a>
    </div>
</body>
</html>
