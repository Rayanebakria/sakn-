<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'housing_db'; // غيّر الاسم إذا كانت قاعدة البيانات اسمها مختلف

$conn = new mysqli($host, $user, $password, $dbname);

// فحص الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}
?>
