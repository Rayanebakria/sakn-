<?php
// بدء الجلسة والتأكد من أن المستخدم مسجل دخول
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// التحقق من أن معرف المستفيد موجود في الرابط
if (!isset($_GET['id'])) {
    die("❌ معرف المستفيد غير موجود.");
}

// الاتصال بقاعدة البيانات
$conn = new mysqli("localhost", "root", "", "housing_db");
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

// حذف المستفيد بناءً على معرفه
$id = intval($_GET['id']);
$stmt = $conn->prepare("DELETE FROM beneficiaries WHERE id = ?");
$stmt->bind_param("i", $id);

// تنفيذ الحذف
if ($stmt->execute()) {
    // إعادة التوجيه إلى صفحة القائمة بعد الحذف
    header("Location: beneficiaries_list.php");
    exit();
} else {
    echo "❌ فشل الحذف.";
}
?>
