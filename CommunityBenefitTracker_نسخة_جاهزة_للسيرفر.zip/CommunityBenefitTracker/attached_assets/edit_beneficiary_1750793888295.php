<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "housing_db");
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM beneficiaries WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$beneficiary = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $national_id = $_POST['national_id'];
    $commune = $_POST['commune'];
    $status = $_POST['status'];

    $update = $conn->prepare("UPDATE beneficiaries SET full_name = ?, national_id = ?, commune = ?, status = ? WHERE id = ?");
    $update->bind_param("ssssi", $full_name, $national_id, $commune, $status, $id);
    if ($update->execute()) {
        header("Location: beneficiaries_list.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات مستفيد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to bottom right, #0d1b2a, #1b263b);
            color: white;
            font-family: 'Cairo', sans-serif;
            min-height: 100vh;
            padding-top: 50px;
        }
        .container {
            background-color: #1c2541;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.5);
        }
        .form-control, .form-select {
            background-color: #e0e0e0;
            border-radius: 10px;
        }
        .btn-save {
            background-color: #00ffaa;
            color: black;
            font-weight: bold;
            border-radius: 12px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container col-md-6 offset-md-3">
    <h2>✏️ تعديل بيانات المستفيد</h2>
    <form method="POST">
        <div class="mb-3">
            <label>الاسم الكامل</label>
            <input type="text" name="full_name" class="form-control" required value="<?= htmlspecialchars($beneficiary['full_name']) ?>">
        </div>
        <div class="mb-3">
            <label>رقم التعريف الوطني</label>
            <input type="text" name="national_id" class="form-control" required value="<?= htmlspecialchars($beneficiary['national_id']) ?>">
        </div>
        <div class="mb-3">
            <label>البلدية</label>
            <input type="text" name="commune" class="form-control" required value="<?= htmlspecialchars($beneficiary['commune']) ?>">
        </div>
        <div class="mb-3">
            <label>الحالة</label>
            <select name="status" class="form-select" required>
                <option value="مقبول" <?= $beneficiary['status'] == 'مقبول' ? 'selected' : '' ?>>✅ مقبول</option>
                <option value="مرفوض" <?= $beneficiary['status'] == 'مرفوض' ? 'selected' : '' ?>>❌ مرفوض</option>
                <option value="قيد الدراسة" <?= $beneficiary['status'] == 'قيد الدراسة' ? 'selected' : '' ?>>⏳ قيد الدراسة</option>
            </select>
        </div>
        <button type="submit" class="btn btn-save w-100">💾 حفظ التغييرات</button>
    </form>
</div>
</body>
</html>
