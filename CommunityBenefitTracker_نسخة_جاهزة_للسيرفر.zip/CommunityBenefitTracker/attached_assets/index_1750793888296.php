<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>الصفحة الرئيسية - السكنات الاجتماعية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      color: white;
      font-family: 'Cairo', sans-serif;
      text-align: center;
      padding-top: 100px;
    }
    h1, h2, h3 {
      margin: 10px 0;
    }
    .btn-lg {
      width: 250px;
      margin: 10px auto;
      font-size: 1.2rem;
    }
    .language-switch {
      position: absolute;
      top: 20px;
      left: 20px;
    }
  </style>
</head>
<body>

  <div class="language-switch">
    <a href="#" class="btn btn-outline-light btn-sm">Français</a>
  </div>

  <h4>الجمهورية الجزائرية الديمقراطية الشعبية</h4>
  <h4>وزارة السكن و العمران</h4>
  <h3>المنصة الرقمية للسكنات الاجتماعية</h3>

  <div class="d-flex flex-column align-items-center mt-5">
    <a href="login.php" class="btn btn-primary btn-lg">تسجيل الدخول</a>
    <a href="register.php" class="btn btn-success btn-lg">إنشاء حساب</a>
  </div>

</body>
</html>
