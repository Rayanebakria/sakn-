<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>تسجيل الدخول - السكنات الاجتماعية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      color: white;
      font-family: 'Cairo', sans-serif;
      padding: 40px 0;
    }
    .login-container {
      background-color: rgba(255, 255, 255, 0.05);
      padding: 40px;
      border-radius: 15px;
      max-width: 500px;
      margin: auto;
    }
    .form-title {
      text-align: center;
      margin-bottom: 30px;
    }
    .header {
      text-align: center;
      margin-bottom: 20px;
    }
    .header h5 {
      margin: 0;
      font-size: 18px;
    }
  </style>
</head>
<body>
  <div class="header">
    <h5>الجمهورية الجزائرية الديمقراطية الشعبية</h5>
    <h5>وزارة السكن والعمران</h5>
    <h5>المنصة الرقمية للسكنات الاجتماعية</h5>
  </div>

  <div class="login-container">
    <h2 class="form-title">🔐 تسجيل الدخول</h2>
    <form method="post" action="process_login.php">
      <div class="mb-3">
        <label>اسم المستخدم</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>كلمة المرور</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <div class="form-check mb-3">
        <input type="checkbox" class="form-check-input" name="remember">
        <label class="form-check-label">تذكرني</label>
      </div>
      <button type="submit" class="btn btn-success w-100">دخول</button>
    </form>
  </div>
</body>
</html>
