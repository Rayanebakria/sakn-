<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>إنشاء حساب - السكنات الاجتماعية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      color: white;
      font-family: 'Cairo', sans-serif;
      padding: 40px 0;
    }
    .form-container {
      background-color: rgba(255, 255, 255, 0.05);
      padding: 40px;
      border-radius: 15px;
      max-width: 900px;
      margin: auto;
    }
    .form-title {
      text-align: center;
      margin-bottom: 30px;
    }
    label {
      font-weight: bold;
    }
    .form-check-label {
      font-weight: normal;
    }
    .form-section {
      margin-bottom: 40px;
    }
    .header {
      text-align: center;
      margin-bottom: 20px;
    }
    .header h5 {
      margin: 0;
      font-size: 20px;
    }
    .header h4 {
      margin: 0;
      font-size: 22px;
    }
    .header h3 {
      margin: 0;
      font-size: 24px;
    }
  </style>
</head>
<body>
  <div class="header">
    <h5>الجمهورية الجزائرية الديمقراطية الشعبية</h5>
    <h4>وزارة السكن و العمران</h4>
    <h3>المنصة الرقمية للسكنات الاجتماعية</h3>
  </div>

  <div class="form-container">
    <h2 class="form-title">📝 إنشاء حساب جديد</h2>
    <form method="post" action="submit_register.php" enctype="multipart/form-data">
      <!-- المعلومات الشخصية -->
      <div class="form-section">
        <h4>المعلومات الشخصية</h4>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label>اللقب (بالعربية)</label>
            <input type="text" class="form-control" name="last_ar" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>الاسم (بالعربية)</label>
            <input type="text" class="form-control" name="first_ar" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>Nom (بالفرنسية)</label>
            <input type="text" class="form-control" name="last_fr" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>Prénom (بالفرنسية)</label>
            <input type="text" class="form-control" name="first_fr" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>تاريخ الميلاد</label>
            <input type="date" class="form-control" name="birth_date" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>مكان الميلاد</label>
            <input type="text" class="form-control" name="birth_place" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>رقم التعريف الوطني</label>
            <input type="text" class="form-control" name="national_id" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>الحالة المدنية</label>
            <select class="form-select" name="status" required>
              <option>أعزب</option>
              <option>متزوج</option>
              <option>مطلق</option>
              <option>أرمل</option>
            </select>
          </div>
          <div class="col-md-6 mb-3">
            <label>عدد الأطفال</label>
            <input type="number" class="form-control" name="children_count">
          </div>
          <div class="col-md-6 mb-3">
            <label>رقم الهاتف</label>
            <input type="text" class="form-control" name="phone" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>البريد الإلكتروني</label>
            <input type="email" class="form-control" name="email" required>
          </div>
        </div>
      </div>

      <!-- معلومات الإقامة -->
      <div class="form-section">
        <h4>معلومات الإقامة الحالية</h4>
        <div class="mb-3">
          <label>العنوان الكامل</label>
          <textarea class="form-control" name="address" required></textarea>
        </div>
        <div class="mb-3">
          <label>نوع السكن الحالي</label>
          <select class="form-select" name="housing_type" required>
            <option>مع العائلة</option>
            <option>مستأجر</option>
            <option>سكن هش</option>
            <option>بدون سكن</option>
          </select>
        </div>
        <div class="mb-3">
          <label>عدد سنوات الإقامة في البلدية</label>
          <input type="number" class="form-control" name="residency_years">
        </div>
      </div>

      <!-- المعلومات المهنية -->
      <div class="form-section">
        <h4>المعلومات المهنية</h4>
        <div class="mb-3">
          <label>الوضعية المهنية</label>
          <select class="form-select" name="job_status" required>
            <option>موظف</option>
            <option>عامل يومي</option>
            <option>بطال</option>
            <option>متقاعد</option>
            <option>حرفي</option>
          </select>
        </div>
        <div class="mb-3">
          <label>جهة العمل</label>
          <input type="text" class="form-control" name="employer">
        </div>
        <div class="mb-3">
          <label>الدخل الشهري</label>
          <input type="number" class="form-control" name="salary">
        </div>
      </div>

      <!-- الوثائق المطلوبة -->
      <div class="form-section">
        <h4>الوثائق المطلوبة (PDF أو صورة)</h4>
        <div class="mb-3">
          <label>بطاقة التعريف الوطنية</label>
          <input type="file" class="form-control" name="doc_id" accept="application/pdf,image/*" required>
        </div>
        <div class="mb-3">
          <label>بطاقة الإقامة</label>
          <input type="file" class="form-control" name="doc_residence" accept="application/pdf,image/*" required>
        </div>
        <div class="mb-3">
          <label>شهادة الميلاد</label>
          <input type="file" class="form-control" name="doc_birth" accept="application/pdf,image/*">
        </div>
        <div class="mb-3">
          <label>شهادة عائلية</label>
          <input type="file" class="form-control" name="doc_family" accept="application/pdf,image/*">
        </div>
        <div class="mb-3">
          <label>شهادة عدم الملكية</label>
          <input type="file" class="form-control" name="doc_property" accept="application/pdf,image/*">
        </div>
        <div class="mb-3">
          <label>كشف الراتب أو شهادة عدم العمل</label>
          <input type="file" class="form-control" name="doc_income" accept="application/pdf,image/*">
        </div>
      </div>

      <!-- معلومات الحساب -->
      <div class="form-section">
        <h4>معلومات الحساب</h4>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label>اسم المستخدم</label>
            <input type="text" class="form-control" name="username" required>
          </div>
          <div class="col-md-6 mb-3">
            <label>كلمة السر</label>
            <input type="password" class="form-control" name="password" required>
          </div>
        </div>
      </div>

      <!-- تأكيد التسجيل -->
      <div class="form-check mb-4">
        <input class="form-check-input" type="checkbox" required>
        <label class="form-check-label">أتعهد أن المعلومات المدخلة صحيحة</label>
      </div>

      <button type="submit" class="btn btn-success w-100">إرسال الطلب</button>
    </form>
  </div>
</body>
</html>
