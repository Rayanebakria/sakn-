<?php
require_once 'ai_decision.php'; // تأكد أن هذا الملف موجود بجانب هذا الملف

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // استقبال البيانات
    $بيانات = [
        "status" => $_POST['status'] ?? '',
        "children_count" => $_POST['children_count'] ?? 0,
        "housing_type" => $_POST['housing_type'] ?? '',
        "salary" => $_POST['salary'] ?? 0,
        "residency_years" => $_POST['residency_years'] ?? 0
    ];

    // تحليل الطلب باستخدام الذكاء الاصطناعي
    $النتيجة = تقييم_الطلب($بيانات);
    $القرار = $النتيجة['القرار'];
    $الأولوية = $النتيجة['الأولوية'];
} else {
    // في حال الدخول مباشرة بدون POST
    header("Location: signup.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>نتيجة التحليل</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
  <style>
    body {
      background: #2c5364;
      color: white;
      font-family: 'Cairo', sans-serif;
      padding: 40px;
    }
    .result-container {
      background-color: rgba(255, 255, 255, 0.05);
      padding: 40px;
      border-radius: 15px;
      max-width: 700px;
      margin: auto;
      text-align: center;
    }
    .result-container h2 {
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="result-container">
    <h2>📊 نتيجة تحليل طلبك</h2>
    <p><strong>القرار:</strong> <?= htmlspecialchars($القرار) ?></p>
    <p><strong>نقاط الأولوية:</strong> <?= htmlspecialchars($الأولوية) ?> / 100</p>
    <a href="signup.php" class="btn btn-light mt-4">🔙 الرجوع للتسجيل</a>
  </div>
</body>
</html>
