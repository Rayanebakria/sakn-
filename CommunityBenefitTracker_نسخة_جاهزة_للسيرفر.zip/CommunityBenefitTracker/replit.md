# Housing Management System

## Overview

This is a comprehensive Arabic-language social housing management system for Algeria's Ministry of Housing and Urban Development. The system provides a digital platform for citizens to apply for social housing and administrators to manage beneficiaries. It features an AI-powered decision-making system for application evaluation and includes a chatbot for user assistance.

## System Architecture

### Frontend Architecture
- **Technology**: HTML5, CSS3, JavaScript (ES6+)
- **Framework**: Bootstrap 5.3.2 RTL for Arabic language support
- **Language Support**: Primary Arabic (RTL), with French language switching capability
- **UI Components**: Responsive design with gradient backgrounds, cards, forms, and navigation bars
- **Client-side Routing**: Static HTML pages with JavaScript-based interactions

### Backend Architecture
- **Runtime**: Node.js 20
- **Framework**: Express.js 5.1.0
- **Session Management**: Express-session for user authentication
- **File Upload**: Multer for document handling
- **Password Security**: Bcrypt for password hashing
- **API Design**: RESTful endpoints with JSON responses

## Key Components

### 1. Authentication System
- **User Types**: Citizens and administrators
- **Security**: BCrypt password hashing with session-based authentication
- **Session Management**: Express-session with configurable security settings

### 2. Application Management
- **Citizen Registration**: Multi-step form with personal, family, and housing information
- **Document Upload**: Support for identity cards, residence certificates, and other required documents
- **Application Tracking**: Real-time status updates for submitted applications

### 3. AI Decision Engine (`ai_decision.js`)
- **Scoring Algorithm**: Multi-criteria evaluation system based on:
  - Marital status (10-20 points)
  - Housing type (10-40 points based on urgency)
  - Employment status (8-25 points)
  - Income thresholds (0-30 points)
  - Number of children (5 points per child)
- **Decision Thresholds**: 
  - Accepted: ≥90 points
  - Under Review: 60-89 points
  - Rejected: <60 points

### 4. Administrative Dashboard
- **Beneficiary Management**: CRUD operations for housing beneficiaries
- **Search and Filtering**: By name, status, and commune
- **Statistics Dashboard**: Real-time counts and analytics
- **Status Management**: Approve, reject, or mark applications under review

### 5. Chatbot Integration
- **API Integration**: OpenAI GPT integration for user assistance
- **Language**: Arabic-language responses
- **Context**: Housing-specific knowledge base

## Data Flow

### Application Submission Flow
1. Citizen creates account via registration form
2. Personal information validation and storage
3. Document upload and verification
4. AI system evaluates application automatically
5. Administrator review for borderline cases
6. Final decision communication to applicant

### Administrative Workflow
1. Administrator login authentication
2. Dashboard overview with statistics
3. Beneficiary list with search/filter capabilities
4. Individual record management (view, edit, delete)
5. Status updates and decision logging

## External Dependencies

### NPM Packages
- **express**: Web application framework
- **mysql2**: MySQL database driver
- **bcrypt**: Password hashing library
- **express-session**: Session management middleware
- **multer**: File upload handling

### CDN Resources
- **Bootstrap 5.3.2 RTL**: UI framework with Arabic language support
- **OpenAI API**: ChatGPT integration for chatbot functionality

## Deployment Strategy

### Environment Configuration
- **Port**: Configurable via environment variable (default: 5000)
- **Database**: MySQL connection with environment variable support
- **Session Secret**: Configurable security key
- **File Storage**: Local filesystem with organized upload directory

### Database Schema
- **Users Table**: Authentication credentials and basic info
- **Applications Table**: Complete application data with AI scoring
- **Beneficiaries Table**: Approved housing recipients
- **Documents Table**: File metadata and storage paths

### Runtime Requirements
- Node.js 20 or higher
- MySQL database server
- File system write permissions for uploads
- Environment variables for sensitive configuration

## Changelog
- June 24, 2025: Initial setup
- June 24, 2025: Enhanced chat icon with modern design and animated pulse
- June 24, 2025: Added trilingual support (Arabic, French, English) with advanced dropdown
- June 24, 2025: Integrated OpenAI GPT-4o for intelligent chatbot responses
- June 24, 2025: Enhanced fallback chatbot system with comprehensive Arabic responses and smart keyword matching
- June 24, 2025: Updated document terminology: "نسخة من بطاقة الهوية" → "بطاقة التعريف الوطنية" and "شهادة إقامة" → "بطاقة إقامة"
- June 24, 2025: Implemented comprehensive mobile-responsive design with optimized icons, layout, and chat interface for phone browsers

## User Preferences

Preferred communication style: Simple, everyday language.