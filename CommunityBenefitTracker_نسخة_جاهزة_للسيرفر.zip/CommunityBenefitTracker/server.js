const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const OpenAI = require('openai');

// Import database and storage (will be converted to use Drizzle)
// const { db } = require('./server/db');
// const { storage } = require('./server/storage');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('.'));
app.use(session({
    secret: process.env.SESSION_SECRET || 'housing_system_secret',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

// File upload configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = 'uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir);
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Database connection
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// OpenAI configuration
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

// Initialize database
async function initializeDatabase() {
    try {
        // Test connection
        const client = await pool.connect();
        client.release();
        console.log('Connected to PostgreSQL database');
        
        // Tables are now created via Drizzle/SQL commands
        console.log('Database tables initialized');
    } catch (error) {
        console.error('Database connection failed:', error);
        process.exit(1);
    }
}

async function createTables() {
    const createUsersTable = `
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `;

    const createBeneficiariesTable = `
        CREATE TABLE IF NOT EXISTS beneficiaries (
            id SERIAL PRIMARY KEY,
            full_name VARCHAR(255) NOT NULL,
            national_id VARCHAR(50) UNIQUE NOT NULL,
            commune VARCHAR(100) NOT NULL,
            status VARCHAR(20) DEFAULT 'قيد الدراسة' CHECK (status IN ('مقبول', 'مرفوض', 'قيد الدراسة')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `;

    const createApplicationsTable = `
        CREATE TABLE IF NOT EXISTS applications (
            id SERIAL PRIMARY KEY,
            first_name_ar VARCHAR(100) NOT NULL,
            last_name_ar VARCHAR(100) NOT NULL,
            first_name_fr VARCHAR(100) NOT NULL,
            last_name_fr VARCHAR(100) NOT NULL,
            birth_date DATE NOT NULL,
            birth_place VARCHAR(100) NOT NULL,
            national_id VARCHAR(50) UNIQUE NOT NULL,
            marital_status VARCHAR(20) NOT NULL CHECK (marital_status IN ('أعزب', 'متزوج', 'مطلق', 'أرمل')),
            children_count INT DEFAULT 0,
            phone VARCHAR(20) NOT NULL,
            email VARCHAR(255) NOT NULL,
            address TEXT NOT NULL,
            housing_type VARCHAR(30) NOT NULL CHECK (housing_type IN ('مع العائلة', 'مستأجر', 'سكن هش', 'بدون سكن')),
            residency_years INT DEFAULT 0,
            job_status VARCHAR(20) NOT NULL CHECK (job_status IN ('موظف', 'عامل يومي', 'بطال', 'متقاعد', 'حرفي')),
            employer VARCHAR(200),
            salary INT DEFAULT 0,
            status VARCHAR(20) DEFAULT 'قيد الدراسة' CHECK (status IN ('مقبول', 'مرفوض', 'قيد الدراسة')),
            priority_score INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    `;

    await pool.query(createUsersTable);
    await pool.query(createBeneficiariesTable);
    await pool.query(createApplicationsTable);
    
    // Create default admin user
    const adminEmail = 'rayanebakria13@gmail.com';
    const adminPassword = 'bakria1999';
    const hashedPassword = await bcrypt.hash(adminPassword, 10);
    
    try {
        await pool.query(
            'INSERT INTO users (email, password) VALUES ($1, $2) ON CONFLICT (email) DO NOTHING',
            [adminEmail, hashedPassword]
        );
        console.log('Default admin user created');
    } catch (error) {
        console.log('Admin user already exists or error creating:', error.message);
    }
}

// Authentication middleware
function requireAuth(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({ error: 'Authentication required' });
    }
}

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Login endpoint
app.post('/api/login', async (req, res) => {
    const { email, password } = req.body;
    
    try {
        const result = await pool.query(
            'SELECT id, password FROM users WHERE email = $1',
            [email]
        );
        
        if (result.rows.length === 0) {
            return res.status(401).json({ error: 'البريد الإلكتروني غير مسجل' });
        }
        
        const user = result.rows[0];
        const isPasswordValid = await bcrypt.compare(password, user.password);
        
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'كلمة المرور غير صحيحة' });
        }
        
        req.session.userId = user.id;
        res.json({ success: true, message: 'تم تسجيل الدخول بنجاح' });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'خطأ في الخادم' });
    }
});

// Logout endpoint
app.post('/api/logout', (req, res) => {
    req.session.destroy();
    res.json({ success: true });
});

// Submit application
app.post('/api/submit-application', upload.fields([
    { name: 'doc_id', maxCount: 1 },
    { name: 'doc_residence', maxCount: 1 },
    { name: 'doc_birth', maxCount: 1 },
    { name: 'doc_family', maxCount: 1 },
    { name: 'doc_property', maxCount: 1 },
    { name: 'doc_income', maxCount: 1 }
]), async (req, res) => {
    try {
        const {
            first_ar, last_ar, first_fr, last_fr,
            birth_date, birth_place, national_id,
            status, children_count, phone, email,
            address, housing_type, residency_years,
            job_status, employer, salary
        } = req.body;

        // Calculate AI decision
        const aiResult = calculatePriority({
            status,
            children_count: parseInt(children_count) || 0,
            housing_type,
            salary: parseInt(salary) || 0,
            residency_years: parseInt(residency_years) || 0
        });

        await pool.query(`
            INSERT INTO applications (
                first_name_ar, last_name_ar, first_name_fr, last_name_fr,
                birth_date, birth_place, national_id, marital_status,
                children_count, phone, email, address, housing_type,
                residency_years, job_status, employer, salary,
                status, priority_score
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
        `, [
            first_ar, last_ar, first_fr, last_fr,
            birth_date, birth_place, national_id, status,
            children_count, phone, email, address, housing_type,
            residency_years, job_status, employer, salary,
            aiResult.decision, aiResult.priority
        ]);

        res.json({
            success: true,
            decision: aiResult.decision,
            priority: aiResult.priority,
            message: 'تم إرسال الطلب بنجاح'
        });
    } catch (error) {
        console.error('Application submission error:', error);
        res.status(500).json({ error: 'فشل في إرسال الطلب' });
    }
});

// Get beneficiaries (admin only)
app.get('/api/beneficiaries', requireAuth, async (req, res) => {
    try {
        const { search, status, commune } = req.query;
        let query = 'SELECT * FROM beneficiaries WHERE 1=1';
        const params = [];
        let paramIndex = 1;

        if (search) {
            query += ` AND full_name ILIKE $${paramIndex}`;
            params.push(`%${search}%`);
            paramIndex++;
        }

        if (status) {
            query += ` AND status = $${paramIndex}`;
            params.push(status);
            paramIndex++;
        }

        if (commune) {
            query += ` AND commune ILIKE $${paramIndex}`;
            params.push(`%${commune}%`);
            paramIndex++;
        }

        query += ' ORDER BY id ASC';

        const result = await pool.query(query, params);
        
        // Get statistics
        const statsResult = await pool.query(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'مقبول' THEN 1 ELSE 0 END) as accepted,
                SUM(CASE WHEN status = 'مرفوض' THEN 1 ELSE 0 END) as rejected,
                SUM(CASE WHEN status = 'قيد الدراسة' THEN 1 ELSE 0 END) as pending
            FROM beneficiaries
        `);

        res.json({
            beneficiaries: result.rows,
            stats: statsResult.rows[0]
        });
    } catch (error) {
        console.error('Get beneficiaries error:', error);
        res.status(500).json({ error: 'فشل في جلب البيانات' });
    }
});

// Add beneficiary (admin only)
app.post('/api/beneficiaries', requireAuth, async (req, res) => {
    try {
        const { full_name, national_id, commune, status } = req.body;
        
        await pool.query(
            'INSERT INTO beneficiaries (full_name, national_id, commune, status) VALUES ($1, $2, $3, $4)',
            [full_name, national_id, commune, status]
        );
        
        res.json({ success: true, message: 'تم إضافة المستفيد بنجاح' });
    } catch (error) {
        console.error('Add beneficiary error:', error);
        res.status(500).json({ error: 'فشل في إضافة المستفيد' });
    }
});

// Update beneficiary (admin only)
app.put('/api/beneficiaries/:id', requireAuth, async (req, res) => {
    try {
        const { id } = req.params;
        const { full_name, national_id, commune, status } = req.body;
        
        await pool.query(
            'UPDATE beneficiaries SET full_name = $1, national_id = $2, commune = $3, status = $4 WHERE id = $5',
            [full_name, national_id, commune, status, id]
        );
        
        res.json({ success: true, message: 'تم تحديث البيانات بنجاح' });
    } catch (error) {
        console.error('Update beneficiary error:', error);
        res.status(500).json({ error: 'فشل في تحديث البيانات' });
    }
});

// Delete beneficiary (admin only)
app.delete('/api/beneficiaries/:id', requireAuth, async (req, res) => {
    try {
        const { id } = req.params;
        
        await pool.query('DELETE FROM beneficiaries WHERE id = $1', [id]);
        
        res.json({ success: true, message: 'تم حذف المستفيد بنجاح' });
    } catch (error) {
        console.error('Delete beneficiary error:', error);
        res.status(500).json({ error: 'فشل في حذف المستفيد' });
    }
});

// Chat API endpoint with OpenAI integration
app.post('/api/chat', async (req, res) => {
    const { message } = req.body;
    
    if (!message || message.trim() === '') {
        return res.status(400).json({ error: 'الرسالة مطلوبة' });
    }

    // Enhanced fallback response system
    const fallbackResponses = {
        'مرحبا': 'أهلاً وسهلاً بك في نظام السكنات الاجتماعية!\n\nيمكنني مساعدتك في:\n• معرفة شروط التسجيل\n• الوثائق المطلوبة\n• خطوات التقديم\n• معايير الأولوية\n\nما الذي تود معرفته؟',
        
        'شروط': 'شروط الحصول على السكن الاجتماعي:\n\n✅ عدم ملكية سكن (أساسي)\n✅ الدخل الشهري أقل من 6 مرات الحد الأدنى للأجر\n✅ الإقامة الدائمة في البلدية لأكثر من 5 سنوات\n✅ الجنسية الجزائرية\n✅ عدم الاستفادة مسبقاً من سكن اجتماعي',
        
        'وثائق': 'الوثائق المطلوبة للتسجيل:\n\n🆔 بطاقة التعريف الوطنية\n🏠 بطاقة إقامة حديثة\n💰 كشف راتب (3 أشهر الأخيرة)\n👨‍👩‍👧‍👦 شهادة عائلية\n🚫 شهادة عدم ملكية سكن\n📝 شهادة ميلاد (للأطفال)\n\nملاحظة: جميع الوثائق يجب أن تكون أصلية أو مصدقة',
        
        'خطوات': 'خطوات التسجيل في النظام:\n\n1️⃣ إنشاء حساب جديد\n2️⃣ تعبئة الاستمارة الشخصية\n3️⃣ إدخال معلومات العائلة\n4️⃣ رفع الوثائق المطلوبة\n5️⃣ مراجعة البيانات وتأكيد التسجيل\n6️⃣ انتظار نتيجة التقييم الآلي\n7️⃣ متابعة الطلب عبر النظام',
        
        'معايير': 'معايير الأولوية في التقييم:\n\n👨‍👩‍👧‍👦 الحالة المدنية (متزوج أولوية أكبر)\n🏚️ نوع السكن الحالي (السكن الهش = أولوية عالية)\n👶 عدد الأطفال (5 نقاط لكل طفل)\n💼 الوضع المهني (العاطل عن العمل = أولوية)\n💰 مستوى الدخل (الدخل المنخفض = نقاط أعلى)',
        
        'نقاط': 'نظام النقاط للتقييم:\n\n• 90+ نقطة = قبول مبدئي ✅\n• 60-89 نقطة = تحت المراجعة 🔍\n• أقل من 60 = رفض مؤقت ❌\n\nالنظام يستخدم ذكاء اصطناعي لحساب النقاط بناءً على معايير عادلة ومحددة مسبقاً.',
        
        'متى': 'مواعيد معالجة الطلبات:\n\n📅 التقييم الآلي: فوري (أقل من دقيقة)\n👨‍💼 المراجعة الإدارية: 15-30 يوم عمل\n📞 الرد النهائي: 30-45 يوم عمل\n\nيمكنك متابعة حالة طلبك في أي وقت عبر حسابك في النظام.',
        
        'مساعدة': 'طرق الحصول على المساعدة:\n\n📧 البريد الإلكتروني: support@housing.gov.dz\n☎️ الهاتف: 021-XX-XX-XX\n🏢 زيارة مكتب البلدية\n💬 استخدام هذا المساعد الآلي\n\nأوقات العمل: الأحد-الخميس 8:00-16:00',
        
        'default': 'مرحباً! أنا المساعد الآلي للسكنات الاجتماعية.\n\nيمكنك سؤالي عن:\n• "شروط" - شروط التسجيل\n• "وثائق" - الوثائق المطلوبة\n• "خطوات" - كيفية التسجيل\n• "معايير" - معايير الأولوية\n• "متى" - مواعيد الرد\n• "مساعدة" - طرق التواصل\n\nجرب كتابة إحدى هذه الكلمات للحصول على معلومات مفصلة!'
    };

    try {
        // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        const response = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: [
                {
                    role: "system",
                    content: `أنت مساعد ذكي متخصص في نظام السكنات الاجتماعية في الجزائر. مهمتك مساعدة المواطنين في:

1. شرح شروط الحصول على السكن الاجتماعي
2. توضيح الوثائق المطلوبة للتسجيل
3. شرح خطوات التسجيل والتقديم
4. الإجابة على الأسئلة حول الأهلية والمعايير
5. توضيح مراحل معالجة الطلبات

معلومات مهمة:
- الشروط الأساسية: عدم ملكية سكن، دخل محدود، إقامة دائمة في البلدية
- الوثائق: بطاقة هوية، شهادة إقامة، شهادة عدم ملكية، كشف راتب، شهادة عائلية
- المعايير: الحالة المدنية، عدد الأطفال، نوع السكن الحالي، الوضع المهني، الدخل الشهري
- معايير الأولوية: المتزوجون أولوية أكبر، السكن الهش يحصل على نقاط أعلى، البطالة تزيد الأولوية
- عملية التقييم: النظام يستخدم ذكاء اصطناعي لتقييم الطلبات وإعطاء نقاط أولوية

أجب باللغة العربية بطريقة مهذبة ومساعدة. كن دقيقاً ومفيداً واستخدم المعلومات المقدمة أعلاه.`
                },
                {
                    role: "user",
                    content: message
                }
            ],
            max_tokens: 500,
            temperature: 0.7
        });

        const botResponse = response.choices[0].message.content;
        
        // Save successful AI chat to database
        try {
            await pool.query(
                'INSERT INTO chat_messages (message, response, is_ai_response, created_at) VALUES ($1, $2, $3, NOW())',
                [message, botResponse, true]
            );
        } catch (dbError) {
            console.log('Failed to save AI chat message to database:', dbError);
        }
        
        res.json({ response: botResponse });

    } catch (error) {
        console.error('OpenAI API Error:', error);
        
        let response = fallbackResponses['default'];
        const lowerMessage = message.toLowerCase();
        
        // Smart keyword matching
        const keywords = Object.keys(fallbackResponses);
        for (let keyword of keywords) {
            if (lowerMessage.includes(keyword) || 
                lowerMessage.includes(keyword.substring(0, 3)) || // partial match
                (keyword === 'وثائق' && (lowerMessage.includes('مطلوب') || lowerMessage.includes('ورق'))) ||
                (keyword === 'شروط' && lowerMessage.includes('شرط')) ||
                (keyword === 'خطوات' && (lowerMessage.includes('تسجيل') || lowerMessage.includes('طريقة'))) ||
                (keyword === 'معايير' && (lowerMessage.includes('أولوية') || lowerMessage.includes('تقييم'))) ||
                (keyword === 'مرحبا' && (lowerMessage.includes('مرحب') || lowerMessage.includes('سلام') || lowerMessage.includes('أهلا')))) {
                response = fallbackResponses[keyword];
                break;
            }
        }
        
        // Save chat interaction to database
        try {
            await pool.query(
                'INSERT INTO chat_messages (message, response, is_ai_response, created_at) VALUES ($1, $2, $3, NOW())',
                [message, response, false]
            );
        } catch (dbError) {
            console.log('Failed to save chat message to database:', dbError);
        }
        
        res.json({ response });
    }
});

// AI Decision calculation function
function calculatePriority(data) {
    let score = 0;
    
    // Marital status
    switch(data.status) {
        case 'أعزب': score += 10; break;
        case 'متزوج': score += 20; break;
        case 'مطلق': score += 15; break;
        case 'أرمل': score += 18; break;
    }
    
    // Children count
    score += data.children_count * 5;
    
    // Housing type
    switch(data.housing_type) {
        case 'مع العائلة': score += 10; break;
        case 'مستأجر': score += 20; break;
        case 'سكن هش': score += 30; break;
        case 'بدون سكن': score += 40; break;
    }
    
    // Income
    if (data.salary < 20000) {
        score += 30;
    } else if (data.salary < 40000) {
        score += 15;
    }
    
    // Residency years
    score += Math.min(20, data.residency_years) * 1;
    
    // Decision
    let decision;
    if (score >= 90) {
        decision = 'مقبول';
    } else if (score >= 60) {
        decision = 'قيد الدراسة';
    } else {
        decision = 'مرفوض';
    }
    
    return {
        decision,
        priority: score
    };
}

// Start server
initializeDatabase().then(() => {
    app.listen(PORT, '0.0.0.0', () => {
        console.log(`Server running on http://0.0.0.0:${PORT}`);
    });
});
