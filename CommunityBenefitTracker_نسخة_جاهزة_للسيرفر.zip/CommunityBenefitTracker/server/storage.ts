import { users, applications, beneficiaries, documents, chat_messages, type User, type InsertUser, type Application, type InsertApplication, type Beneficiary, type InsertBeneficiary, type ChatMessage, type InsertChatMessage } from "../shared/schema";
import { db } from "./db";
import { eq, like, and, desc, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  
  // Application operations
  createApplication(insertApplication: InsertApplication): Promise<Application>;
  getApplicationById(id: number): Promise<Application | undefined>;
  getApplicationsByUserId(userId: number): Promise<Application[]>;
  updateApplicationStatus(id: number, status: string, aiScore?: number, recommendations?: string): Promise<void>;
  
  // Beneficiary operations
  getBeneficiaries(filters?: { search?: string; status?: string; commune?: string }): Promise<Beneficiary[]>;
  createBeneficiary(insertBeneficiary: InsertBeneficiary): Promise<Beneficiary>;
  updateBeneficiary(id: number, data: Partial<Beneficiary>): Promise<void>;
  deleteBeneficiary(id: number): Promise<void>;
  getBeneficiaryStats(): Promise<{ total: number; accepted: number; rejected: number; pending: number }>;
  
  // Chat operations
  saveChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage>;
  getChatHistory(userId?: number, limit?: number): Promise<ChatMessage[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Application operations
  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const [application] = await db
      .insert(applications)
      .values(insertApplication)
      .returning();
    return application;
  }

  async getApplicationById(id: number): Promise<Application | undefined> {
    const [application] = await db.select().from(applications).where(eq(applications.id, id));
    return application || undefined;
  }

  async getApplicationsByUserId(userId: number): Promise<Application[]> {
    return await db.select().from(applications).where(eq(applications.user_id, userId));
  }

  async updateApplicationStatus(id: number, status: string, aiScore?: number, recommendations?: string): Promise<void> {
    const updateData: any = { status, updated_at: new Date() };
    if (aiScore !== undefined) updateData.ai_score = aiScore;
    if (recommendations) updateData.ai_recommendations = recommendations;
    
    await db.update(applications).set(updateData).where(eq(applications.id, id));
  }

  // Beneficiary operations
  async getBeneficiaries(filters?: { search?: string; status?: string; commune?: string }): Promise<Beneficiary[]> {
    let query = db.select().from(beneficiaries);
    
    const conditions = [];
    if (filters?.search) {
      conditions.push(like(beneficiaries.full_name, `%${filters.search}%`));
    }
    if (filters?.status) {
      conditions.push(eq(beneficiaries.status, filters.status));
    }
    if (filters?.commune) {
      conditions.push(like(beneficiaries.commune, `%${filters.commune}%`));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query.orderBy(desc(beneficiaries.created_at));
  }

  async createBeneficiary(insertBeneficiary: InsertBeneficiary): Promise<Beneficiary> {
    const [beneficiary] = await db
      .insert(beneficiaries)
      .values(insertBeneficiary)
      .returning();
    return beneficiary;
  }

  async updateBeneficiary(id: number, data: Partial<Beneficiary>): Promise<void> {
    await db.update(beneficiaries).set(data).where(eq(beneficiaries.id, id));
  }

  async deleteBeneficiary(id: number): Promise<void> {
    await db.delete(beneficiaries).where(eq(beneficiaries.id, id));
  }

  async getBeneficiaryStats(): Promise<{ total: number; accepted: number; rejected: number; pending: number }> {
    const [stats] = await db
      .select({
        total: sql<number>`count(*)`,
        accepted: sql<number>`count(case when status = 'مقبول' then 1 end)`,
        rejected: sql<number>`count(case when status = 'مرفوض' then 1 end)`,
        pending: sql<number>`count(case when status = 'قيد الدراسة' then 1 end)`
      })
      .from(beneficiaries);
    
    return stats;
  }

  // Chat operations
  async saveChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chat_messages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getChatHistory(userId?: number, limit: number = 50): Promise<ChatMessage[]> {
    let query = db.select().from(chat_messages);
    
    if (userId) {
      query = query.where(eq(chat_messages.user_id, userId));
    }
    
    return await query.orderBy(desc(chat_messages.created_at)).limit(limit);
  }
}

export const storage = new DatabaseStorage();