import { pgTable, serial, varchar, text, integer, timestamp, boolean } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table for authentication
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  password: varchar('password', { length: 255 }).notNull(),
  role: varchar('role', { length: 50 }).notNull().default('citizen'),
  created_at: timestamp('created_at').defaultNow(),
});

// Applications table for housing applications
export const applications = pgTable('applications', {
  id: serial('id').primaryKey(),
  user_id: integer('user_id').references(() => users.id),
  
  // Personal Information
  first_name_ar: varchar('first_name_ar', { length: 100 }).notNull(),
  last_name_ar: varchar('last_name_ar', { length: 100 }).notNull(),
  first_name_fr: varchar('first_name_fr', { length: 100 }).notNull(),
  last_name_fr: varchar('last_name_fr', { length: 100 }).notNull(),
  birth_date: varchar('birth_date', { length: 20 }).notNull(),
  birth_place: varchar('birth_place', { length: 100 }).notNull(),
  national_id: varchar('national_id', { length: 20 }).notNull().unique(),
  marital_status: varchar('marital_status', { length: 20 }).notNull(),
  children_count: integer('children_count').default(0),
  phone: varchar('phone', { length: 20 }).notNull(),
  
  // Address Information
  address: text('address').notNull(),
  housing_type: varchar('housing_type', { length: 50 }).notNull(),
  residency_years: integer('residency_years').default(0),
  
  // Professional Information
  job_status: varchar('job_status', { length: 50 }).notNull(),
  employer: varchar('employer', { length: 200 }),
  monthly_salary: integer('monthly_salary').default(0),
  
  // AI Evaluation
  ai_score: integer('ai_score').default(0),
  status: varchar('status', { length: 50 }).default('قيد الدراسة'),
  ai_recommendations: text('ai_recommendations'),
  
  created_at: timestamp('created_at').defaultNow(),
  updated_at: timestamp('updated_at').defaultNow(),
});

// Beneficiaries table for approved housing recipients
export const beneficiaries = pgTable('beneficiaries', {
  id: serial('id').primaryKey(),
  application_id: integer('application_id').references(() => applications.id),
  full_name: varchar('full_name', { length: 200 }).notNull(),
  national_id: varchar('national_id', { length: 20 }).notNull(),
  commune: varchar('commune', { length: 100 }).notNull(),
  status: varchar('status', { length: 50 }).notNull(),
  housing_assigned: varchar('housing_assigned', { length: 200 }),
  assigned_date: timestamp('assigned_date'),
  created_at: timestamp('created_at').defaultNow(),
});

// Documents table for uploaded files
export const documents = pgTable('documents', {
  id: serial('id').primaryKey(),
  application_id: integer('application_id').references(() => applications.id),
  document_type: varchar('document_type', { length: 100 }).notNull(),
  file_name: varchar('file_name', { length: 255 }).notNull(),
  file_path: varchar('file_path', { length: 500 }).notNull(),
  uploaded_at: timestamp('uploaded_at').defaultNow(),
});

// Chat messages table for AI assistant
export const chat_messages = pgTable('chat_messages', {
  id: serial('id').primaryKey(),
  user_id: integer('user_id').references(() => users.id),
  message: text('message').notNull(),
  response: text('response').notNull(),
  is_ai_response: boolean('is_ai_response').default(false),
  created_at: timestamp('created_at').defaultNow(),
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  applications: many(applications),
  chatMessages: many(chat_messages),
}));

export const applicationsRelations = relations(applications, ({ one, many }) => ({
  user: one(users, {
    fields: [applications.user_id],
    references: [users.id],
  }),
  beneficiary: one(beneficiaries),
  documents: many(documents),
}));

export const beneficiariesRelations = relations(beneficiaries, ({ one }) => ({
  application: one(applications, {
    fields: [beneficiaries.application_id],
    references: [applications.id],
  }),
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  application: one(applications, {
    fields: [documents.application_id],
    references: [applications.id],
  }),
}));

export const chatMessagesRelations = relations(chat_messages, ({ one }) => ({
  user: one(users, {
    fields: [chat_messages.user_id],
    references: [users.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;
export type Beneficiary = typeof beneficiaries.$inferSelect;
export type InsertBeneficiary = typeof beneficiaries.$inferInsert;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;
export type ChatMessage = typeof chat_messages.$inferSelect;
export type InsertChatMessage = typeof chat_messages.$inferInsert;