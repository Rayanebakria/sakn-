
# Community Benefit Tracker

منصة رقمية لتسيير توزيع السكنات الاجتماعية باستخدام الذكاء الاصطناعي.

## 📦 المتطلبات:
- Node.js
- npm

## ⚙️ التثبيت:

```bash
npm install
```

## 🚀 التشغيل:

```bash
npm start
```

## ✅ التشغيل الدائم (باستخدام PM2):

```bash
pm2 start server.js --name community-tracker
pm2 save
pm2 startup
```

## 🌐 بعد التشغيل:
افتح المتصفح على:
http://localhost:3000
