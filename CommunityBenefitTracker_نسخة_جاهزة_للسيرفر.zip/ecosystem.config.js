
module.exports = {
  apps : [{
    name: "community-tracker",
    script: "./server.js",
    watch: true,
    env: {
      NODE_ENV: "production",
      PORT: 3000
    }
  }]
}
